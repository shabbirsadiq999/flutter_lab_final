# Password Generator
A simple password generator I made for myself to help me futher my understanding of the flutter framework and dart programming language, and as a utility I use often.

## Screenshots
<div style="text-align: center">
  <table>
    <tr>
      <td style="text-align: center">
        <img src="https://raw.githubusercontent.com/jdudarewicz/Flutter-Password-Generator/master/screenshots/First_Boot.png" width="200" />
      </td>
      <td style="text-align: center">
        <img src="https://raw.githubusercontent.com/jdudarewicz/Flutter-Password-Generator/master/screenshots/Generated_Passphrase.png" width="200" />
      </td>
      <td style="text-align: center">
        <img src="https://raw.githubusercontent.com/jdudarewicz/Flutter-Password-Generator/master/screenshots/Copying.png" width="200" />
      </td>
      <td style="text-align: center">
        <img src="https://raw.githubusercontent.com/jdudarewicz/Flutter-Password-Generator/master/screenshots/No_Character_Selected.png" width="200" />
      </td>
    </tr>
  </table>
 </div>
